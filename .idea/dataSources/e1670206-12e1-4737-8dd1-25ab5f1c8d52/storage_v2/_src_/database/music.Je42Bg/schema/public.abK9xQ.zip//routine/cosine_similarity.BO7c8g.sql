create function cosine_similarity(x cube, y cube) returns real
    language plpgsql
as
$$
DECLARE
	origin cube := cube(array[0,0,0,0,0,0,0,0,0,0,0,0]);
	declare mag_x real;
	declare mag_y real;
BEGIN
	select origin <-> x into mag_x;
	select origin <-> y into mag_y;
	return (dot_product(x, y) / (mag_x * mag_y));
END;
$$;

alter function cosine_similarity(cube, cube) owner to postgres;

