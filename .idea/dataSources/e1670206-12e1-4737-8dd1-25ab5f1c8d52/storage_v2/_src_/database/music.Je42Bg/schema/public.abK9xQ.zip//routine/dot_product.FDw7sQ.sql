create function dot_product(x cube, y cube) returns real
    language plpgsql
as
$$
DECLARE
	declare product real := 0.0;
	declare dimension real;
BEGIN
	select cube_dim(x) into dimension;
	for i in 1..dimension loop 
		product := product + (cube_ll_coord(x, i) * cube_ll_coord(y, i));
	end loop;
	return product;
END;
$$;

alter function dot_product(cube, cube) owner to postgres;

