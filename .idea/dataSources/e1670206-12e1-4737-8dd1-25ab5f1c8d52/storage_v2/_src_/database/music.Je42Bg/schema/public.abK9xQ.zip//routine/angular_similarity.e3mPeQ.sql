create function angular_similarity(x cube, y cube) returns real
    language plpgsql
as
$$
DECLARE
	declare pi real := 3.14159265359;
	declare cos_sim real;
BEGIN
	select cosine_similarity(x, y) into cos_sim;
	return 1 - (acos(cos_sim) / pi);
END;
$$;

alter function angular_similarity(cube, cube) owner to postgres;

